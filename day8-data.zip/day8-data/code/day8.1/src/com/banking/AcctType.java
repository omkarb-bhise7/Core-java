package com.banking;

public enum AcctType {
SAVING,CURRENT,FD,DMAT,LOAN
}
